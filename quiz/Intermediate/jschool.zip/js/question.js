
const quiz = [
    {
        q: 'Who is the Parent Company Of Google ?',
        options:['Amazon','Microsoft','Apple','Alphabet'],
        answer:3
    },
    {
        q: 'Which one is a Union Territory of the following ?',
        options:['Daman & Diu','New Delhi','Mumbai','Hyderabad'],
        answer:0
    },
    {
        q: 'What is the cleanest creature to have in your house ?',
        options:['Spider','Your Husband Derry','Crocodile','Rat'],
        answer:3,       
        img: 'img/rat.jpeg',
    },
    {
        q: 'What is my favorite animal ?',
        options:['Butterfly','Derry','My Husband','Elephant'],
        answer:3,       
        img: 'img/elephant.jpeg',
    },
    {
        q: 'Who is the Richest Person In the World ?',
        options:['Bill Gates','Elon Musk','Bernard Arnault & Family','Jeff Bezos'],
        answer:2
    },
    {
        q: 'Who is the BEST Tutor ever ?',
        options:['Albert Einstein','Hitler','Denny','Tutor Joan'],
        answer:3
    },
    {
        q: 'What is Full form of C.B.I ?',
        options:['Central Bank Of India','Crime Branch Of India','Central Bureau Of Investigation','Corporate Bussiness Intelligence'],
        answer:2
    },
    {
        q: 'Which is the only country that is not a member of the United Nations ?',
        options:['United States','India','China','Japan'],
        answer:3
    },
    {
        q: 'Which of the following is the highest mountain peak in India ?',
        options:['Mount Everest','Kanchenjunga','Nanda Devi','CAnnapurna'],
        answer:1
    },
    {
        q: 'Where is Mount Everest located ?',
        options:['Nepal','India','China','Bhutan'],
        answer:0
    },
    {
        q: 'Whos the best husband in the world ?',
        options:['George Clooney','Harris Smith','Michael Jackson','Derry'],
        answer:3
    },
    {
        q: 'What do you do after you see a bin ?',
        options:['Wash your hands','Lick your fingers','Tell Joan','Chop your hands off'],
        answer:0
    }
]